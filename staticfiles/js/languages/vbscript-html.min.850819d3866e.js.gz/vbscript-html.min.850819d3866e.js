/*! `vbscript-html` grammar compiled for Highlight.js 11.6.0 */
(()=>{var e=(()=>{"use strict";return e=>({name:"VBScript in HTML",
subLanguage:"xml",contains:[{begin:"<%",end:"%>",subLanguage:"vbscript"}]})})()
;hljs.registerLanguage("vbscript-html",e)})();