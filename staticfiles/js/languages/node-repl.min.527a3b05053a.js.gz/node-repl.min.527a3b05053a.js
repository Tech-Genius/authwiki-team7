/*! `node-repl` grammar compiled for Highlight.js 11.6.0 */
(()=>{var a=(()=>{"use strict";return a=>({name:"Node REPL",contains:[{
className:"meta.prompt",starts:{end:/ |$/,starts:{end:"$",
subLanguage:"javascript"}},variants:[{begin:/^>(?=[ ]|$)/},{
begin:/^\.\.\.(?=[ ]|$)/}]}]})})();hljs.registerLanguage("node-repl",a)})();